import React, { FC } from "react";
import Hero from "../UI/Hero";
import MovieCarousel from "../UI/MovieCarousel";

const HomePage: FC = () => (
  <div className="min-h-screen bg-transparent text-white overflow-x-hidden pb-20 md:pb-0">
    <Hero endpoint="movie/popular" />
    <main className="max-w-7xl mx-auto py-8 sm:py-12 px-4 sm:px-6 lg:px-8 space-y-12">
      <MovieCarousel title="Trending Now" endpoint="trending/movie/week" />
      <MovieCarousel title="Now Playing" endpoint="movie/now_playing" />
      <MovieCarousel title="Top Rated Movies" endpoint="movie/top_rated" />
      <MovieCarousel title="Top Rated TV Shows" endpoint="tv/top_rated" />
      <MovieCarousel title="Upcoming" endpoint="movie/upcoming" />
      <div className="pt-8 pb-12 text-center">
        <p className="text-xs uppercase tracking-[.35em] text-white/30">Developed by</p>
        <p className="mt-2 text-lg font-black aponjon-gradient aponjon-glow">Yaseen Ahmed</p>
      </div>
    </main>
  </div>
);

export default HomePage;
