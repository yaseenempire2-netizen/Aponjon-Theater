import { useState, useEffect, FC } from "react";
import { Link, NavLink } from "react-router-dom";
import { FiLogIn, FiSearch, FiHome, FiFilm, FiTv, FiUser } from "react-icons/fi";
import { useAuth } from "../../context/AuthContext";

interface NavbarProps { onSearchClick: () => void; }

const navLinks = [
  { path: "/", label: "Home" },
  { path: "/movies", label: "Movies" },
  { path: "/tv-shows", label: "TV Shows" },
];

const Navbar: FC<NavbarProps> = ({ onSearchClick }) => {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const { user, logout } = useAuth();

  useEffect(() => {
    const onScroll = () => setIsScrolled(window.scrollY > 18);
    window.addEventListener("scroll", onScroll);
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  return (
    <>
      <nav className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        isScrolled ? "glass border-b border-white/5" : "bg-gradient-to-b from-black/70 to-transparent"
      }`}>
        <div className="max-w-7xl mx-auto px-4 sm:px-6">
          <div className="flex items-center justify-between h-[72px]">
            <Link to="/" className="group flex items-center gap-2">
              <span className="w-9 h-9 rounded-xl grid place-items-center bg-[#69ff9a]/10 border border-[#69ff9a]/20 shadow-[0_0_24px_rgba(105,255,154,.08)]">
                <span className="text-[#69ff9a] text-lg">✦</span>
              </span>
              <span className="text-xl sm:text-2xl font-black tracking-tight aponjon-gradient aponjon-glow">
                Aponjon Theater
              </span>
            </Link>

            <div className="hidden md:flex items-center gap-1 rounded-full bg-white/[.035] border border-white/[.06] p-1">
              {navLinks.map(link => (
                <NavLink key={link.path} to={link.path} className={({isActive}) =>
                  `px-4 py-2 rounded-full text-sm font-semibold transition ${
                    isActive ? "bg-[#67ff98]/10 text-[#70ff9d]" : "text-white/60 hover:text-white"
                  }`
                }>{link.label}</NavLink>
              ))}
            </div>

            <div className="flex items-center gap-2">
              <button onClick={onSearchClick} aria-label="Search"
                className="w-10 h-10 grid place-items-center rounded-full text-white/70 hover:text-[#70ff9d] hover:bg-white/5 transition">
                <FiSearch size={20}/>
              </button>
              <div className="relative">
                {user ? (
                  <>
                    <button onClick={() => setIsMenuOpen(v => !v)}
                      className="w-10 h-10 rounded-full overflow-hidden border border-[#70ff9d]/30 hover:border-[#70ff9d] transition">
                      <img src={user.profilePicture || `https://ui-avatars.com/api/?name=${user.username}&background=0b1712&color=70ff9d`}
                        alt="Profile" className="w-full h-full object-cover"/>
                    </button>
                    {isMenuOpen && (
                      <div className="absolute right-0 mt-2 w-48 glass rounded-2xl p-2">
                        <Link to="/profile" onClick={() => setIsMenuOpen(false)}
                          className="block px-3 py-2.5 rounded-xl text-sm text-white/75 hover:bg-white/5 hover:text-white">Profile</Link>
                        <button onClick={() => { logout(); setIsMenuOpen(false); }}
                          className="w-full text-left px-3 py-2.5 rounded-xl text-sm text-red-300 hover:bg-red-400/10">Logout</button>
                      </div>
                    )}
                  </>
                ) : (
                  <Link to="/login" aria-label="Login" className="w-10 h-10 grid place-items-center rounded-full text-white/70 hover:text-[#70ff9d] hover:bg-white/5">
                    <FiLogIn size={20}/>
                  </Link>
                )}
              </div>
            </div>
          </div>
        </div>
      </nav>

      <div className="md:hidden fixed bottom-3 left-3 right-3 z-50 glass rounded-2xl px-2 py-2 border border-white/[.08]">
        <div className="grid grid-cols-4">
          {[
            ["/", <FiHome size={19}/>, "Home"],
            ["/movies", <FiFilm size={19}/>, "Movies"],
            ["/tv-shows", <FiTv size={19}/>, "TV"],
            [user ? "/profile" : "/login", <FiUser size={19}/>, "Me"],
          ].map(([path, icon, label]) => (
            <NavLink key={String(path)} to={String(path)} className={({isActive}) =>
              `flex flex-col items-center gap-1 py-1.5 text-[10px] font-semibold transition ${
                isActive ? "text-[#70ff9d]" : "text-white/45"
              }`
            }>{icon}<span>{label}</span></NavLink>
          ))}
        </div>
      </div>
    </>
  );
};

export default Navbar;
