import React, { useEffect, useState, FC } from "react";
import { Link } from "react-router-dom";
import { motion } from "framer-motion";
import { FiPlay, FiInfo } from "react-icons/fi";
import type { ContentItem } from "../../types";

interface HeroProps { endpoint: string; }

const Hero: FC<HeroProps> = ({ endpoint }) => {
  const [featuredMovie, setFeaturedMovie] = useState<ContentItem | null>(null);
  const [loading, setLoading] = useState(true);
  const apiKey = import.meta.env.VITE_TMDB_API_KEY;

  useEffect(() => {
    const fetchFeaturedMovie = async () => {
      setLoading(true);
      try {
        const response = await fetch(`https://api.themoviedb.org/3/${endpoint}?api_key=${apiKey}&language=en-US&page=1`);
        const data = await response.json();
        if (data.results?.length) setFeaturedMovie(data.results[Math.floor(Math.random() * Math.min(5, data.results.length))]);
      } catch (error) { console.error("Error fetching featured movie:", error); }
      finally { setLoading(false); }
    };
    fetchFeaturedMovie();
  }, [apiKey, endpoint]);

  if (loading || !featuredMovie) return <div className="w-full h-[78vh] min-h-[540px] bg-[#07110f] animate-pulse" />;

  const title = featuredMovie.title || featuredMovie.name || "Featured";
  const backdropUrl = featuredMovie.backdrop_path
    ? `https://image.tmdb.org/t/p/original${featuredMovie.backdrop_path}`
    : "/fallback-image.jpg";
  const overview = featuredMovie.overview?.length > 180 ? `${featuredMovie.overview.slice(0, 177)}...` : featuredMovie.overview;

  return (
    <section className="relative w-full h-[78vh] min-h-[540px] overflow-hidden">
      <div className="absolute inset-0">
        <img src={backdropUrl} alt={title} className="w-full h-full object-cover object-center scale-[1.02]" />
        <div className="absolute inset-0 bg-gradient-to-t from-[#050908] via-[#050908]/55 to-[#050908]/5" />
        <div className="absolute inset-0 bg-gradient-to-r from-[#050908]/95 via-[#050908]/55 to-transparent" />
        <div className="absolute inset-0 bg-[#32d96b]/[.025] mix-blend-screen" />
      </div>

      <motion.div initial={{opacity:0, y:24}} animate={{opacity:1, y:0}} transition={{duration:.7}}
        className="relative z-10 h-full max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex items-end pb-16 sm:pb-20">
        <div className="max-w-2xl">
          <div className="flex items-center gap-2 mb-4 text-xs font-bold uppercase tracking-[.25em] text-[#70ff9d]">
            <span className="w-7 h-px bg-[#70ff9d]"/> Featured Tonight
          </div>
          <h1 className="text-4xl sm:text-6xl lg:text-7xl font-black tracking-[-.04em] leading-[.95] text-white drop-shadow-2xl">{title}</h1>
          <div className="flex items-center gap-4 mt-5 text-sm">
            <span className="text-[#70ff9d] font-bold">★ {featuredMovie.vote_average?.toFixed(1) || "N/A"}</span>
            <span className="text-white/45">TMDB</span>
          </div>
          <p className="mt-4 text-sm sm:text-base leading-7 text-white/65 max-w-xl">{overview}</p>
          <div className="mt-7 flex flex-wrap gap-3">
            <Link to={`/${featuredMovie.title !== undefined ? "movie" : "tv"}/${featuredMovie.id}`}
              className="inline-flex items-center gap-2 rounded-full bg-[#69ff9a] text-[#041008] px-6 py-3 font-extrabold shadow-[0_0_30px_rgba(105,255,154,.16)] hover:bg-[#8affaF] transition">
              <FiPlay fill="currentColor"/> Explore
            </Link>
            <Link to={`/${featuredMovie.title !== undefined ? "movie" : "tv"}/${featuredMovie.id}`}
              className="inline-flex items-center gap-2 rounded-full bg-white/10 border border-white/10 backdrop-blur-md px-5 py-3 font-bold text-white hover:bg-white/15 transition">
              <FiInfo/> Details
            </Link>
          </div>
        </div>
      </motion.div>
    </section>
  );
};

export default Hero;
